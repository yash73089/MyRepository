Warning
=======

These portability headers are **internal implementation details**.

They are intended to ensure that Folly can build on a variety of platforms.

They are not intended to help you build your programs on these platforms.

They are, and will remain, undocumented. They are, and will remain, subject to
rapid, immediate, and drastic changes - including full rewrites and merciless
deletions - without notice.

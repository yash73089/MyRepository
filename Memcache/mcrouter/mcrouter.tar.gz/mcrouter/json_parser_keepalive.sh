#!/bin/bash
cloudcomponentid=$1
1> /tmp/rundeck_test_mcrouter.txt
START=0
END=$(jq '.comps.comp | length' /usr/local/netmagic/cloud/bin/shell_scripts/memcached/mcrouter/temp/json_output_$cloudcomponentid.txt)

for (( i=$START; i<=$END; i++ ))
do
   type=`cat /usr/local/netmagic/cloud/bin/shell_scripts/memcached/mcrouter/temp/json_output_$cloudcomponentid.txt | jq .comps.comp[$i].type |  tr -d '"'`
#echo "$type"
	if [ "$type" == "mcrouter_master" ]; then
#		echo "This is master server"
		masterPrivateIp=`cat /usr/local/netmagic/cloud/bin/shell_scripts/memcached/mcrouter/temp/json_output_$cloudcomponentid.txt | jq .comps.comp[$i].private_ip | tr -d '"'`
                virtualIp=IPADDR
		masterComponentId=`cat /usr/local/netmagic/cloud/bin/shell_scripts/memcached/mcrouter/temp/json_output_$cloudcomponentid.txt | jq .comps.comp[$i].cloud_app_component_id | tr -d '"'`
                sed -i "s/10.21.9.100/$virtualIp/g" /usr/local/netmagic/cloud/bin/shell_scripts/memcached/mcrouter/temp/keepalive_conf_master_$cloudcomponentid.txt
                /usr/local/bin/perl  /usr/local/netmagic/cloud/bin/perl/memcached/mcrouter/keepalive_master.pl $masterComponentId $cloudcomponentid
                 ext_stat=`echo $?`
                 if [ $ext_stat -ne 0 ]; then
                                echo "Failed"
                                exit 1
                        fi

#                echo "$masterComponentId:Success" >> /tmp/rundeck_test_mcrouter.txt
       fi
done
### master done###

### Slave ###

for (( i=$START; i<=$END; i++ ))
do
   type=`cat /usr/local/netmagic/cloud/bin/shell_scripts/memcached/mcrouter/temp/json_output_$cloudcomponentid.txt | jq .comps.comp[$i].type | tr -d '"'`
	if [  "$type" == "mcrouter_slave" ]; then
		slavePrivateIp=`cat /usr/local/netmagic/cloud/bin/shell_scripts/memcached/mcrouter/temp/json_output_$cloudcomponentid.txt | jq .comps.comp[$i].private_ip | tr -d '"'`
		slaveComponentId=`cat /usr/local/netmagic/cloud/bin/shell_scripts/memcached/mcrouter/temp/json_output_$cloudcomponentid.txt | jq .comps.comp[$i].cloud_app_component_id | tr -d '"'`
                sed -i "s/10.21.9.100/$virtualIp/g" /usr/local/netmagic/cloud/bin/shell_scripts/memcached/mcrouter/temp/keepalive_conf_slave_$cloudcomponentid.txt
        	/usr/local/bin/perl  /usr/local/netmagic/cloud/bin/perl/memcached/mcrouter/keepalive_slave.pl $slaveComponentId $cloudcomponentid
		 ext_stat=`echo $?`
                 if [ $ext_stat -ne 0 ]; then
                                echo "Failed"
                                exit 1
                        fi
                
                echo "Success" >> /tmp/rundeck_test_mcrouter.txt

	fi
done	



